# 📊 Mini BI — Streamlit dentro de um notebook Databricks

Front-end Streamlit rodando como **subprocess** de um notebook num cluster clássico,
sem Databricks Apps. Dropdown de dashboards configuráveis em YAML + chat com **Genie** ou com um
**agente text-to-SQL** (Foundation Model API) para perguntar sobre os dados.

## Arquitetura

```
Navegador ──► driver proxy ──► Streamlit :8501  (subprocess)
                                              │  HTTP 127.0.0.1 + token
                                              ▼
                                  bridge.py :8765  (thread no notebook)
                                    ├─ spark.sql(...)            → KPIs, gráficos, filtros
                                    ├─ Genie Conversation API    → chat (se genie_space_id)
                                    └─ /serving-endpoints/...    → agente text-to-SQL (fallback)
```

O Streamlit não acessa o `spark` do notebook diretamente, por isso a ponte: ela reaproveita a
sessão Spark do cluster (sem SQL Warehouse para o painel) e a autenticação do notebook.

## Arquivos

| Arquivo | Função |
|---|---|
| `00_launcher.py` | Notebook: instala libs, sobe ponte + Streamlit, gera o link do driver proxy |
| `bridge.py` | Servidor local: SQL somente leitura, schema, Genie, agente LLM |
| `app.py` | Streamlit: dropdown, filtros, KPIs, gráficos Plotly, chat IA, prévia/CSV |
| `dashboards.yaml` | Catálogo de dashboards (adicione os seus aqui) |

## Como usar

1. Importe a pasta no Workspace (ex.: `/Workspace/Users/voce@empresa.com/minibi/`).
   `00_launcher.py` vira notebook automaticamente ao importar.
2. Abra `00_launcher`, anexe a um cluster clássico e rode as células em ordem.
3. Clique no link exibido. Deixe a célula **Keep-alive** rodando enquanto usa.

### Acesso

O link usa o **driver proxy** (`https://<workspace>/driver-proxy/o/<org>/<cluster>/8501/`), autenticado
pelo próprio Databricks — só quem tem acesso ao cluster abre. Requer **cluster clássico** (all-purpose);
no serverless o driver proxy não existe.

## Configurando dashboards

```yaml
dashboards:
  meu_dash:
    titulo: "Meu painel"
    tabela: catalogo.schema.tabela
    genie_space_id: "01ef..."          # opcional; vazio = agente LLM
    filtros:  [{ coluna: data_venda, tipo: data }, { coluna: regiao, tipo: multiselect }]
    kpis:     [{ titulo: Receita, expr: "SUM(valor)", formato: moeda }]
    graficos:
      - { tipo: linha, titulo: "Receita diária", x: "DATE(data_venda)", y: "SUM(valor)", largura: 2 }
      - { tipo: barra_h, titulo: "Por região", x: regiao, y: "SUM(valor)", ordem: y_desc }
```

Tipos de gráfico: `linha`, `barra`, `barra_h`, `area`, `pizza`, `dispersao`, `tabela`
(ou `sql:` livre com `{tabela}` e `{where}`). Com `auto: true` o app monta tudo pelo schema.
O arquivo é relido a cada interação, então dá para editar o YAML sem reiniciar.

## IA

- **Genie** (recomendado): crie um Genie Space com as tabelas, copie o ID da URL
  (`.../genie/rooms/<ID>`) para `genie_space_id`. Mantém o contexto da conversa e usa o SQL Warehouse do Space.
- **Agente LLM**: sem Genie, o app manda schema + amostra para o endpoint do widget `llm_endpoint`,
  gera SQL, executa no Spark (com uma tentativa de autocorreção) e resume o resultado em português.
  Confirme o nome de um endpoint disponível em *Serving* no seu workspace.

Os filtros ativos no painel são enviados como contexto para a IA.

## Segurança e limites

- A ponte escuta só em `127.0.0.1` e exige um token aleatório por execução.
- SQL do app/IA passa por um filtro de **somente leitura**; as permissões do Unity Catalog do usuário que
  roda o notebook continuam valendo — **todos que usam o app enxergam os dados com as permissões dele**.
- O app vive enquanto a sessão do notebook estiver ativa (e o cluster ligado).
- Resultados limitados a 50 mil linhas por consulta; cache de 5 min (botão “Atualizar dados” limpa).
