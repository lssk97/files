"""
app.py — Mini BI em Streamlit, executado como subprocess de um notebook serverless do Databricks.
Toda leitura de dados e chamadas de IA passam pela ponte local (bridge.py) que roda no notebook.
"""
from __future__ import annotations

import datetime as dt
import os
from pathlib import Path

import pandas as pd
import plotly.express as px
import requests
import streamlit as st
import yaml

# ----------------------------------------------------------------------------- configuração
BRIDGE = f"http://127.0.0.1:{os.environ.get('MINIBI_BRIDGE_PORT', '8765')}"
TOKEN = os.environ.get("MINIBI_BRIDGE_TOKEN", "")
SENHA = os.environ.get("MINIBI_SENHA", "")
CONFIG = Path(os.environ.get("MINIBI_CONFIG", Path(__file__).with_name("dashboards.yaml")))

st.set_page_config(page_title="Mini BI", page_icon="📊", layout="wide")
st.markdown(
    """
    <style>
      .block-container {padding-top: 1.6rem; padding-bottom: 2rem;}
      div[data-testid="stMetric"] {background: rgba(127,127,127,.07); border: 1px solid rgba(127,127,127,.18);
                                   border-radius: 12px; padding: 14px 16px;}
      div[data-testid="stMetricValue"] {font-size: 1.65rem;}
      .minibi-sub {opacity:.7; margin-top:-.6rem; margin-bottom:1rem;}
    </style>
    """,
    unsafe_allow_html=True,
)
PALETA = ["#2F6FDE", "#E8833A", "#2BA37F", "#C2457A", "#7A5CDB", "#B79A2E", "#3AA6C2", "#8C8C8C"]
px.defaults.color_discrete_sequence = PALETA
px.defaults.template = "plotly_white"


# ----------------------------------------------------------------------------- acesso (opcional)
if SENHA and not st.session_state.get("autenticado"):
    st.title("🔒 Mini BI")
    s = st.text_input("Senha", type="password")
    if st.button("Entrar") and s == SENHA:
        st.session_state["autenticado"] = True
        st.rerun()
    st.stop()


# ----------------------------------------------------------------------------- cliente da ponte
class ErroBridge(Exception):
    pass


def _chamar(metodo: str, rota: str, timeout: int = 300, **kw):
    try:
        r = requests.request(metodo, BRIDGE + rota, headers={"X-Bridge-Token": TOKEN}, timeout=timeout, **kw)
    except requests.ConnectionError:
        raise ErroBridge("A ponte com o Spark não está respondendo. Rode de novo a célula do launcher no notebook.")
    dados = r.json()
    if r.status_code != 200:
        raise ErroBridge(dados.get("erro", "erro desconhecido"))
    return dados


def _para_df(payload: dict | None) -> pd.DataFrame | None:
    if not payload:
        return None
    df = pd.DataFrame(payload["linhas"], columns=payload["colunas"])
    tipos = payload.get("tipos") or {}
    for c in df.columns:
        t = tipos.get(c, "")
        if "datetime" in t:
            df[c] = pd.to_datetime(df[c], errors="coerce")
        elif not t:  # resultados do Genie chegam como texto
            conv = pd.to_numeric(df[c], errors="coerce")
            if conv.notna().sum() == df[c].notna().sum():
                df[c] = conv
    return df


@st.cache_data(ttl=300, show_spinner=False)
def sql(consulta: str, limite: int = 50_000) -> pd.DataFrame:
    return _para_df(_chamar("POST", "/sql", json={"sql": consulta, "limite": limite}))


@st.cache_data(ttl=3600, show_spinner=False)
def schema(tabela: str) -> list[dict]:
    return _chamar("GET", "/schema", params={"tabela": tabela})


# ----------------------------------------------------------------------------- helpers
NUMERICOS = ("int", "bigint", "smallint", "tinyint", "double", "float", "decimal", "long")
DATAS = ("date", "timestamp")


def q(col: str) -> str:
    return "`" + col.replace("`", "``") + "`"


def lit(v) -> str:
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(v)
    return "'" + str(v).replace("\\", "\\\\").replace("'", "\\'") + "'"


def fmt(v, formato: str = "numero", moeda: str = "R$") -> str:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return "–"
    v = float(v)

    def br(x, casas):
        return f"{x:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")

    if formato == "moeda":
        if abs(v) >= 1e6:
            return f"{moeda} {br(v / 1e6, 2)} mi"
        return f"{moeda} {br(v, 2)}"
    if formato == "pct":
        return f"{br(v * 100, 1)}%"
    if formato == "decimal":
        return br(v, 2)
    if abs(v) >= 1e6:
        return f"{br(v / 1e6, 1)} mi"
    return br(v, 0)


def carregar_config() -> dict:
    with open(CONFIG, encoding="utf-8") as f:
        return yaml.safe_load(f)["dashboards"]


def config_automatica(tabela: str) -> dict:
    """Monta filtros, KPIs e gráficos a partir do schema da tabela."""
    cols = schema(tabela)
    nums = [c["nome"] for c in cols if c["tipo"].startswith(NUMERICOS)]
    datas = [c["nome"] for c in cols if c["tipo"].startswith(DATAS)]
    textos = [c["nome"] for c in cols if c["tipo"] == "string"]

    filtros = [{"coluna": d, "tipo": "data"} for d in datas[:1]]
    filtros += [{"coluna": t, "tipo": "multiselect"} for t in textos[:2]]
    kpis = [{"titulo": "Registros", "expr": "COUNT(*)", "formato": "numero"}]
    kpis += [{"titulo": f"Σ {n}", "expr": f"SUM({q(n)})", "formato": "numero"} for n in nums[:3]]

    graficos = []
    if datas:
        graficos.append({"tipo": "linha", "titulo": f"Registros por dia ({datas[0]})",
                         "x": f"DATE({q(datas[0])})", "y": "COUNT(*)", "largura": 2})
    for t in textos[:4]:
        graficos.append({"tipo": "barra_h", "titulo": f"Top 10 – {t}", "x": q(t), "y": "COUNT(*)",
                         "ordem": "y_desc", "limite": 10})
    if nums:
        graficos.append({"tipo": "tabela", "titulo": "Estatísticas numéricas", "largura": 2,
                         "sql": "SELECT " + ", ".join(
                             f"MIN({q(n)}) AS min_{n}, AVG({q(n)}) AS media_{n}, MAX({q(n)}) AS max_{n}"
                             for n in nums[:4]) + " FROM {tabela} {where}"})
    return {"filtros": filtros, "kpis": kpis, "graficos": graficos}


# ----------------------------------------------------------------------------- filtros
def render_filtros(dash_id: str, tabela: str, filtros: list[dict]) -> tuple[str, list[str]]:
    """Desenha os filtros na sidebar e devolve (cláusula WHERE, descrições legíveis)."""
    colunas = {c["nome"]: c["tipo"] for c in schema(tabela)}
    condicoes, legiveis = [], []
    for f in filtros:
        col, tipo = f["coluna"], f.get("tipo", "multiselect")
        if col not in colunas:
            st.sidebar.warning(f"Coluna `{col}` não existe em {tabela}.")
            continue
        chave = f"{dash_id}:{col}"
        rotulo = f.get("rotulo", col)

        if tipo == "multiselect":
            opcoes = sql(f"SELECT DISTINCT {q(col)} AS v FROM {tabela} WHERE {q(col)} IS NOT NULL ORDER BY 1 LIMIT 500")
            escolha = st.sidebar.multiselect(rotulo, opcoes["v"].tolist(), key=chave)
            if escolha:
                condicoes.append(f"{q(col)} IN ({', '.join(lit(v) for v in escolha)})")
                legiveis.append(f"{col} ∈ {escolha}")

        elif tipo == "data":
            lim = sql(f"SELECT MIN(DATE({q(col)})) AS a, MAX(DATE({q(col)})) AS b FROM {tabela}")
            a, b = pd.to_datetime(lim["a"].iloc[0]), pd.to_datetime(lim["b"].iloc[0])
            if pd.isna(a):
                continue
            ini, fim = a.date(), b.date()
            sel = st.sidebar.date_input(rotulo, (ini, fim), min_value=ini, max_value=fim, key=chave, format="DD/MM/YYYY")
            if isinstance(sel, (tuple, list)) and len(sel) == 2 and (sel[0] != ini or sel[1] != fim):
                condicoes.append(f"DATE({q(col)}) BETWEEN '{sel[0]:%Y-%m-%d}' AND '{sel[1]:%Y-%m-%d}'")
                legiveis.append(f"{col} entre {sel[0]:%d/%m/%Y} e {sel[1]:%d/%m/%Y}")

        elif tipo == "intervalo":
            lim = sql(f"SELECT MIN({q(col)}) AS a, MAX({q(col)}) AS b FROM {tabela}")
            a, b = float(lim["a"].iloc[0]), float(lim["b"].iloc[0])
            sel = st.sidebar.slider(rotulo, a, b, (a, b), key=chave)
            if sel != (a, b):
                condicoes.append(f"{q(col)} BETWEEN {sel[0]} AND {sel[1]}")
                legiveis.append(f"{col} entre {sel[0]:.2f} e {sel[1]:.2f}")

    where = ("WHERE " + " AND ".join(condicoes)) if condicoes else ""
    return where, legiveis


# ----------------------------------------------------------------------------- gráficos
def sql_grafico(g: dict, tabela: str, where: str) -> str:
    if g.get("sql"):
        return g["sql"].format(tabela=tabela, where=where)
    tipo = g.get("tipo", "barra")
    if tipo == "tabela":
        return f"SELECT * FROM {tabela} {where} LIMIT {g.get('limite', 200)}"
    limite = g.get("limite", 2000 if tipo in ("linha", "area") else 50)
    cor = g.get("cor")
    sel = f"{g['x']} AS x" + (f", {cor} AS cor" if cor else "") + f", {g['y']} AS y"
    grupo = "1, 2" if cor else "1"
    ordem = "y DESC" if g.get("ordem") == "y_desc" else "x"
    return f"SELECT {sel} FROM {tabela} {where} GROUP BY {grupo} ORDER BY {ordem} LIMIT {limite}"


def figura(df: pd.DataFrame, g: dict):
    tipo = g.get("tipo", "barra")
    cor = "cor" if "cor" in df.columns else None
    rot = {"x": g.get("rotulo_x", ""), "y": g.get("rotulo_y", ""), "cor": ""}
    if tipo == "linha":
        fig = px.line(df, x="x", y="y", color=cor, labels=rot, markers=len(df) < 40)
    elif tipo == "area":
        fig = px.area(df, x="x", y="y", color=cor, labels=rot)
    elif tipo == "barra_h":
        fig = px.bar(df.iloc[::-1], x="y", y="x", color=cor, orientation="h", labels={"x": "", "y": ""})
    elif tipo == "pizza":
        fig = px.pie(df, names="x", values="y", hole=0.5)
    elif tipo == "dispersao":
        fig = px.scatter(df, x="x", y="y", color=cor, labels=rot, opacity=0.55)
    else:
        fig = px.bar(df, x="x", y="y", color=cor, labels=rot)
    fig.update_layout(margin=dict(l=8, r=8, t=8, b=8), height=g.get("altura", 330),
                      legend=dict(orientation="h", y=-0.15), xaxis_title=None, yaxis_title=None)
    return fig


def grafico_automatico(df: pd.DataFrame | None):
    """Escolhe um gráfico simples para resultados do chat."""
    if df is None or len(df) < 2 or len(df.columns) < 2:
        return None
    nums = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    outras = [c for c in df.columns if c not in nums]
    if not nums:
        return None
    y = nums[-1] if outras else nums[1] if len(nums) > 1 else None
    if outras:
        x = outras[0]
        temporal = pd.api.types.is_datetime64_any_dtype(df[x]) or pd.to_datetime(df[x], errors="coerce").notna().all()
        d = df.head(60 if not temporal else 2000)
        fig = px.line(d, x=x, y=y) if temporal else px.bar(d, x=x, y=y)
    elif y:
        fig = px.scatter(df, x=nums[0], y=y)
    else:
        return None
    fig.update_layout(margin=dict(l=8, r=8, t=8, b=8), height=300)
    return fig


# ----------------------------------------------------------------------------- telas
def aba_dashboard(dash: dict, tabela: str, where: str):
    moeda = dash.get("moeda", "R$")
    kpis = dash.get("kpis", [])
    if kpis:
        exprs = ", ".join(f"{k['expr']} AS k{i}" for i, k in enumerate(kpis))
        try:
            linha = sql(f"SELECT {exprs} FROM {tabela} {where}").iloc[0]
            cols = st.columns(len(kpis))
            for i, (k, c) in enumerate(zip(kpis, cols)):
                c.metric(k["titulo"], fmt(linha[f"k{i}"], k.get("formato", "numero"), moeda))
        except ErroBridge as e:
            st.error(f"KPIs: {e}")

    graficos = dash.get("graficos", [])
    i = 0
    while i < len(graficos):
        g = graficos[i]
        if g.get("largura", 1) == 2:
            linha_graficos, i = [g], i + 1
            slots = [st.container()]
        else:
            linha_graficos = [g]
            if i + 1 < len(graficos) and graficos[i + 1].get("largura", 1) != 2:
                linha_graficos.append(graficos[i + 1])
            i += len(linha_graficos)
            slots = st.columns(2)
        for g, slot in zip(linha_graficos, slots):
            with slot:
                with st.container(border=True):
                    st.markdown(f"**{g.get('titulo', '')}**")
                    consulta = sql_grafico(g, tabela, where)
                    try:
                        df = sql(consulta)
                        if df.empty:
                            st.info("Sem dados para os filtros atuais.")
                        elif g.get("tipo") == "tabela":
                            st.dataframe(df, use_container_width=True, hide_index=True, height=g.get("altura", 330))
                        else:
                            st.plotly_chart(figura(df, g), use_container_width=True)
                    except ErroBridge as e:
                        st.error(str(e))
                    with st.expander("SQL", expanded=False):
                        st.code(consulta, language="sql")


SUGESTOES = [
    "Quais são os 5 itens com maior receita?",
    "Como evoluiu o volume mês a mês?",
    "Existe alguma anomalia ou outlier relevante?",
]


def aba_ia(dash_id: str, dash: dict, tabela: str, filtros_legiveis: list[str]):
    space = (dash.get("genie_space_id") or "").strip()
    motor = "Genie" if space else "Agente LLM (text-to-SQL)"
    topo = st.columns([4, 1])
    topo[0].caption(f"Motor: **{motor}** · tabela `{tabela}`"
                    + (f" · filtros ativos: {'; '.join(filtros_legiveis)}" if filtros_legiveis else ""))
    chat_key, conv_key = f"chat:{dash_id}", f"conv:{dash_id}"
    if topo[1].button("🧹 Nova conversa", use_container_width=True):
        st.session_state.pop(chat_key, None)
        st.session_state.pop(conv_key, None)
        st.rerun()

    historico = st.session_state.setdefault(chat_key, [])
    pergunta = None
    if not historico:
        st.markdown("##### Experimente perguntar")
        cols = st.columns(len(dash.get("sugestoes", SUGESTOES)))
        for c, sug in zip(cols, dash.get("sugestoes", SUGESTOES)):
            if c.button(sug, use_container_width=True):
                pergunta = sug

    for i, m in enumerate(historico):
        with st.chat_message(m["role"]):
            st.markdown(m["content"] or "_(sem texto)_")
            if m.get("sql"):
                with st.expander("SQL gerado"):
                    st.code(m["sql"], language="sql")
            df = _para_df(m.get("dados"))
            if df is not None and not df.empty:
                fig = grafico_automatico(df)
                if fig:
                    st.plotly_chart(fig, use_container_width=True, key=f"fig-{dash_id}-{i}")
                st.dataframe(df, use_container_width=True, hide_index=True, height=min(38 * (len(df) + 1), 320))

    pergunta = st.chat_input("Pergunte algo sobre os dados…") or pergunta
    if not pergunta:
        return

    historico.append({"role": "user", "content": pergunta})
    with st.spinner(f"{motor} pensando…"):
        try:
            if space:
                texto_pergunta = pergunta
                if filtros_legiveis:
                    texto_pergunta += f" (considere os filtros: {'; '.join(filtros_legiveis)})"
                r = _chamar("POST", "/genie", timeout=240, json={
                    "space_id": space, "pergunta": texto_pergunta,
                    "conversation_id": st.session_state.get(conv_key)})
                st.session_state[conv_key] = r.get("conversation_id")
                texto = r.get("texto") or r.get("descricao") or "Aqui está o resultado."
            else:
                contexto = dash.get("descricao", "")
                if filtros_legiveis:
                    contexto += " Filtros ativos no painel: " + "; ".join(filtros_legiveis)
                r = _chamar("POST", "/agente", timeout=240, json={
                    "tabelas": [tabela] + dash.get("tabelas_extras", []),
                    "pergunta": pergunta, "contexto": contexto,
                    "historico": [{"role": h["role"], "content": (h.get("sql") or h["content"])}
                                  for h in historico[:-1]]})
                texto = r.get("texto", "")
            historico.append({"role": "assistant", "content": texto, "sql": r.get("sql"), "dados": r.get("dados")})
        except ErroBridge as e:
            historico.append({"role": "assistant", "content": f"⚠️ {e}"})
    st.rerun()


def aba_dados(tabela: str, where: str):
    c1, c2 = st.columns([3, 1])
    limite = c2.number_input("Linhas", 100, 50_000, 1000, step=500)
    df = sql(f"SELECT * FROM {tabela} {where} LIMIT {int(limite)}")
    c1.caption(f"Prévia de `{tabela}` com os filtros aplicados · {len(df):,} linhas".replace(",", "."))
    st.dataframe(df, use_container_width=True, hide_index=True, height=480)
    st.download_button("⬇️ Baixar CSV", df.to_csv(index=False).encode("utf-8"),
                       file_name=f"{tabela.split('.')[-1]}_{dt.date.today():%Y%m%d}.csv", mime="text/csv")
    with st.expander("Schema"):
        st.dataframe(pd.DataFrame(schema(tabela)), hide_index=True, use_container_width=True)


# ----------------------------------------------------------------------------- main
def main():
    try:
        _chamar("GET", "/saude", timeout=5)
    except ErroBridge as e:
        st.error(str(e))
        st.stop()

    dashboards = carregar_config()
    with st.sidebar:
        st.markdown("## 📊 Mini BI")
        dash_id = st.selectbox("Dashboard", list(dashboards), format_func=lambda k: dashboards[k].get("titulo", k))
        if st.button("🔄 Atualizar dados", use_container_width=True):
            sql.clear()
            schema.clear()
            st.rerun()
        st.divider()
        st.markdown("**Filtros**")

    dash = dict(dashboards[dash_id])
    tabela = dash["tabela"]
    if dash.get("auto") or not (dash.get("kpis") or dash.get("graficos")):
        auto = config_automatica(tabela)
        for k, v in auto.items():
            dash.setdefault(k, v)

    where, legiveis = render_filtros(dash_id, tabela, dash.get("filtros", []))

    st.title(dash.get("titulo", dash_id))
    if dash.get("descricao"):
        st.markdown(f"<div class='minibi-sub'>{dash['descricao']}</div>", unsafe_allow_html=True)

    t1, t2, t3 = st.tabs(["📈 Painel", "🤖 Pergunte aos dados", "🗂️ Dados"])
    with t1:
        aba_dashboard(dash, tabela, where)
    with t2:
        aba_ia(dash_id, dash, tabela, legiveis)
    with t3:
        aba_dados(tabela, where)


main()
