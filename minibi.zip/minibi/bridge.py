"""
bridge.py — ponte local entre o Streamlit (subprocess) e a sessão Spark do notebook.

Por que existe:
  O processo do Streamlit NÃO enxerga a variável `spark` do notebook. Em vez de exigir
  um SQL Warehouse só para o front, este módulo sobe um mini servidor HTTP em
  127.0.0.1 (thread daemon dentro do próprio notebook serverless) que:
    • executa SQL com o `spark` do notebook            -> POST /sql
    • devolve schema de tabelas                        -> GET  /schema?tabela=...
    • conversa com um Genie Space (API Conversation)   -> POST /genie
    • agente text-to-SQL via Foundation Model API      -> POST /agente
  A autenticação no workspace é herdada do notebook via WorkspaceClient().
  Toda chamada exige o header X-Bridge-Token (token aleatório gerado pelo launcher).
"""
from __future__ import annotations

import decimal
import json
import re
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

MAX_LINHAS = 50_000
_SQL_PERMITIDO = re.compile(r"^\s*(\(?\s*)*(select|with|show|describe|desc)\b", re.I | re.S)
_SQL_PROIBIDO = re.compile(
    r"\b(insert|update|delete|merge|drop|create|alter|truncate|grant|revoke|copy|optimize|vacuum|refresh|msck|call)\b",
    re.I,
)


# ----------------------------------------------------------------------------- utilidades
def validar_sql_leitura(sql: str) -> str:
    """Bloqueia qualquer coisa que não seja leitura. Proteção simples, não substitui permissões do UC."""
    s = sql.strip().rstrip(";").strip()
    if ";" in s:
        raise ValueError("Apenas um comando SQL por vez.")
    if not _SQL_PERMITIDO.match(s) or _SQL_PROIBIDO.search(re.sub(r"'[^']*'", "''", s)):
        raise ValueError("Somente consultas de leitura (SELECT/WITH/SHOW/DESCRIBE) são permitidas.")
    return s


def df_para_payload(pdf) -> dict:
    """Converte pandas -> dict JSON-safe preservando info de tipos para o front."""
    import pandas as pd

    for c in pdf.columns:
        serie = pdf[c]
        if serie.dtype == object:
            amostra = serie.dropna()
            if len(amostra) and isinstance(amostra.iloc[0], decimal.Decimal):
                pdf[c] = serie.astype(float)
    tipos = {c: str(t) for c, t in pdf.dtypes.items()}
    dados = json.loads(pdf.to_json(orient="split", date_format="iso", default_handler=str, index=False))
    return {"colunas": dados["columns"], "linhas": dados["data"], "tipos": tipos, "n": len(pdf)}


# ----------------------------------------------------------------------------- servidor
class _Estado:
    spark = None
    token = None
    ws = None  # databricks.sdk.WorkspaceClient
    llm_endpoint = "databricks-meta-llama-3-3-70b-instruct"


def _executar_sql(sql: str, limite: int = MAX_LINHAS) -> dict:
    sql = validar_sql_leitura(sql)
    df = _Estado.spark.sql(sql)
    pdf = df.limit(limite).toPandas()
    return df_para_payload(pdf)


def _schema(tabela: str) -> list[dict]:
    if not re.fullmatch(r"[\w`.\-]+", tabela):
        raise ValueError("Nome de tabela inválido.")
    campos = _Estado.spark.table(tabela).schema.fields
    return [{"nome": f.name, "tipo": f.dataType.simpleString()} for f in campos]


# ----------------------------------------------------------------------------- Genie
def _api(metodo: str, caminho: str, corpo: dict | None = None) -> dict:
    return _Estado.ws.api_client.do(metodo, caminho, body=corpo) or {}


def _genie(space_id: str, pergunta: str, conversation_id: str | None) -> dict:
    base = f"/api/2.0/genie/spaces/{space_id}"
    if conversation_id:
        r = _api("POST", f"{base}/conversations/{conversation_id}/messages", {"content": pergunta})
        message_id = r.get("message_id") or r.get("id")
    else:
        r = _api("POST", f"{base}/start-conversation", {"content": pergunta})
        conversation_id = r.get("conversation_id") or r.get("conversation", {}).get("id")
        message_id = r.get("message_id") or r.get("message", {}).get("id")

    # polling até concluir (Genie costuma levar 5–60 s)
    msg, inicio = {}, time.time()
    while time.time() - inicio < 180:
        msg = _api("GET", f"{base}/conversations/{conversation_id}/messages/{message_id}")
        status = msg.get("status")
        if status in ("COMPLETED", "FAILED", "CANCELLED", "QUERY_RESULT_EXPIRED"):
            break
        time.sleep(2)
    else:
        raise TimeoutError("Genie não respondeu em 3 minutos.")

    if msg.get("status") != "COMPLETED":
        erro = (msg.get("error") or {}).get("error") or msg.get("status")
        raise RuntimeError(f"Genie: {erro}")

    saida = {"conversation_id": conversation_id, "texto": "", "sql": None, "descricao": None, "dados": None}
    for att in msg.get("attachments") or []:
        if att.get("text"):
            saida["texto"] += (att["text"].get("content") or "") + "\n"
        if att.get("query"):
            saida["sql"] = att["query"].get("query")
            saida["descricao"] = att["query"].get("description")
            att_id = att.get("attachment_id") or att.get("id")
            try:
                res = _api(
                    "GET",
                    f"{base}/conversations/{conversation_id}/messages/{message_id}"
                    f"/attachments/{att_id}/query-result",
                )
                st = res.get("statement_response", res)
                cols = [c["name"] for c in st["manifest"]["schema"]["columns"]]
                linhas = (st.get("result") or {}).get("data_array") or []
                saida["dados"] = {"colunas": cols, "linhas": linhas, "tipos": {}, "n": len(linhas)}
            except Exception:
                # fallback: reexecuta o SQL do Genie no Spark do notebook
                try:
                    saida["dados"] = _executar_sql(saida["sql"], 5000)
                except Exception:
                    pass
    saida["texto"] = saida["texto"].strip()
    return saida


# ----------------------------------------------------------------------------- Agente LLM (fallback sem Genie)
def _llm(mensagens: list[dict], max_tokens: int = 1500) -> str:
    r = _api(
        "POST",
        f"/serving-endpoints/{_Estado.llm_endpoint}/invocations",
        {"messages": mensagens, "max_tokens": max_tokens, "temperature": 0},
    )
    conteudo = r["choices"][0]["message"]["content"]
    if isinstance(conteudo, list):  # alguns modelos devolvem blocos
        conteudo = "".join(b.get("text", "") for b in conteudo if isinstance(b, dict))
    return conteudo


def _extrair_sql(texto: str) -> str:
    m = re.search(r"```(?:sql)?\s*(.*?)```", texto, re.S | re.I)
    return (m.group(1) if m else texto).strip().rstrip(";")


def _agente(tabelas: list[str], pergunta: str, historico: list[dict], contexto: str = "") -> dict:
    descricao = []
    for t in tabelas:
        cols = ", ".join(f"{c['nome']} ({c['tipo']})" for c in _schema(t))
        amostra = _Estado.spark.table(t).limit(3).toPandas().to_string(index=False)[:1500]
        descricao.append(f"Tabela {t}\nColunas: {cols}\nAmostra:\n{amostra}")

    sistema = (
        "Você é um analista de dados que escreve Spark SQL (Databricks). "
        "Responda SOMENTE com um bloco ```sql ... ``` contendo UMA consulta SELECT que responda à pergunta. "
        "Use apenas as tabelas e colunas fornecidas, nomes totalmente qualificados, e LIMIT 1000 quando listar linhas.\n\n"
        + "\n\n".join(descricao)
        + (f"\n\nContexto do dashboard: {contexto}" if contexto else "")
    )
    msgs = [{"role": "system", "content": sistema}]
    for h in historico[-6:]:
        msgs.append({"role": h["role"], "content": h["content"]})
    msgs.append({"role": "user", "content": pergunta})

    sql, dados, erro = None, None, None
    for _ in range(2):  # 1 tentativa + 1 correção automática
        sql = _extrair_sql(_llm(msgs))
        try:
            dados = _executar_sql(sql, 1000)
            erro = None
            break
        except Exception as e:
            erro = str(e)[:800]
            msgs += [
                {"role": "assistant", "content": f"```sql\n{sql}\n```"},
                {"role": "user", "content": f"A consulta falhou com o erro:\n{erro}\nCorrija e devolva só o SQL."},
            ]
    if erro:
        return {"texto": f"Não consegui gerar uma consulta válida. Último erro: {erro}", "sql": sql, "dados": None}

    previa = json.dumps({"colunas": dados["colunas"], "linhas": dados["linhas"][:40]}, default=str)[:6000]
    texto = _llm(
        [
            {"role": "system", "content": "Você resume resultados de consultas para executivos, em português, de forma objetiva (até 5 frases), citando números."},
            {"role": "user", "content": f"Pergunta: {pergunta}\nSQL: {sql}\nResultado (prévia): {previa}"},
        ],
        600,
    )
    return {"texto": texto.strip(), "sql": sql, "dados": dados}


# ----------------------------------------------------------------------------- HTTP
class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # silencia log no notebook
        pass

    def _responder(self, codigo: int, obj) -> None:
        corpo = json.dumps(obj, default=str).encode()
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _autorizado(self) -> bool:
        if self.headers.get("X-Bridge-Token") != _Estado.token:
            self._responder(401, {"erro": "token inválido"})
            return False
        return True

    def _corpo(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")

    def do_GET(self):
        if not self._autorizado():
            return
        url = urlparse(self.path)
        try:
            if url.path == "/saude":
                self._responder(200, {"ok": True})
            elif url.path == "/schema":
                self._responder(200, _schema(parse_qs(url.query)["tabela"][0]))
            else:
                self._responder(404, {"erro": "rota inexistente"})
        except Exception as e:
            self._responder(400, {"erro": str(e)})

    def do_POST(self):
        if not self._autorizado():
            return
        try:
            b = self._corpo()
            if self.path == "/sql":
                self._responder(200, _executar_sql(b["sql"], int(b.get("limite", MAX_LINHAS))))
            elif self.path == "/genie":
                self._responder(200, _genie(b["space_id"], b["pergunta"], b.get("conversation_id")))
            elif self.path == "/agente":
                self._responder(
                    200, _agente(b["tabelas"], b["pergunta"], b.get("historico", []), b.get("contexto", ""))
                )
            else:
                self._responder(404, {"erro": "rota inexistente"})
        except Exception as e:
            self._responder(400, {"erro": str(e), "detalhe": traceback.format_exc()[-1500:]})


_servidor: ThreadingHTTPServer | None = None


def iniciar_bridge(spark, porta: int, token: str, llm_endpoint: str | None = None) -> None:
    """Sobe (ou reinicia) a ponte em 127.0.0.1:<porta> numa thread daemon."""
    global _servidor
    from databricks.sdk import WorkspaceClient

    parar_bridge()
    _Estado.spark, _Estado.token, _Estado.ws = spark, token, WorkspaceClient()
    if llm_endpoint:
        _Estado.llm_endpoint = llm_endpoint
    _servidor = ThreadingHTTPServer(("127.0.0.1", porta), _Handler)
    threading.Thread(target=_servidor.serve_forever, daemon=True, name="minibi-bridge").start()


def parar_bridge() -> None:
    global _servidor
    if _servidor:
        _servidor.shutdown()
        _servidor.server_close()
        _servidor = None
