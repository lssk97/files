# Databricks notebook source
# MAGIC %md
# MAGIC # 📊 Mini BI — launcher
# MAGIC Sobe o **Streamlit como subprocess** dentro deste notebook (cluster clássico) e abre pelo **driver proxy** do Databricks.
# MAGIC
# MAGIC **Como funciona**
# MAGIC 1. `bridge.py` sobe um servidor HTTP local (`127.0.0.1`) numa thread deste notebook, usando o `spark` daqui para executar SQL e a API do workspace para Genie / Model Serving.
# MAGIC 2. O Streamlit (`app.py`) roda como subprocess e só conversa com essa ponte.
# MAGIC 3. O navegador acessa via `https://<workspace>/driver-proxy/o/<org>/<cluster>/<porta>/` (autenticado pelo próprio Databricks).
# MAGIC
# MAGIC Coloque `00_launcher`, `app.py`, `bridge.py` e `dashboards.yaml` **na mesma pasta** do Workspace e execute as células em ordem.

# COMMAND ----------

# MAGIC %pip install -q "streamlit>=1.37" "plotly>=5.20" pyyaml "databricks-sdk>=0.40"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# DBTITLE 1,Parâmetros
dbutils.widgets.text("porta", "8501", "Porta Streamlit")
dbutils.widgets.text("llm_endpoint", "databricks-meta-llama-3-3-70b-instruct", "Endpoint LLM (sem Genie)")
dbutils.widgets.text("app_dir", "", "Pasta do app (vazio = pasta deste notebook)")

# COMMAND ----------

# DBTITLE 1,Sobe a ponte Spark + o Streamlit
import importlib, os, secrets, subprocess, sys, time
import requests

PORTA = int(dbutils.widgets.get("porta"))
PORTA_BRIDGE = PORTA + 264  # 8765 por padrão
LLM_ENDPOINT = dbutils.widgets.get("llm_endpoint").strip()

# --- contexto (mesmas fontes do teste que funcionou; sem getContext().toJson()) ---------
host = "https://" + spark.conf.get("spark.databricks.workspaceUrl")
org_id = spark.conf.get("spark.databricks.clusterUsageTags.orgId")
cluster_id = spark.conf.get("spark.databricks.clusterUsageTags.clusterId")
_ctx = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
api_token = _ctx.apiToken().getOrElse(None)

APP_DIR = dbutils.widgets.get("app_dir").strip()
if not APP_DIR:
    try:
        nb_path = _ctx.notebookPath().getOrElse(None)
        APP_DIR = os.path.dirname(nb_path if nb_path.startswith("/Workspace") else "/Workspace" + nb_path)
    except Exception:
        APP_DIR = os.getcwd()  # DBR 14+: o diretório de trabalho é a pasta do notebook
assert os.path.exists(os.path.join(APP_DIR, "app.py")), f"app.py não encontrado em {APP_DIR} — preencha o widget 'app_dir'."
print("📁 Pasta do app:", APP_DIR)

# --- 1) ponte Spark ----------------------------------------------------------------------
sys.path.insert(0, APP_DIR)
import bridge
importlib.reload(bridge)
TOKEN = secrets.token_urlsafe(24)
bridge.iniciar_bridge(spark, PORTA_BRIDGE, TOKEN, LLM_ENDPOINT or None, host=host, api_token=api_token)
print(f"🔌 Ponte Spark ativa em 127.0.0.1:{PORTA_BRIDGE}")

# --- 2) encerra execução anterior --------------------------------------------------------
_ant = globals().get("_MINIBI_ST")
if _ant and _ant.poll() is None:
    _ant.terminate()
subprocess.run(["pkill", "-f", f"streamlit run .*--server.port {PORTA}"], check=False)
time.sleep(1)

# --- 3) Streamlit como subprocess ---------------------------------------------------------
# Igual ao teste que funcionou: SEM --server.baseUrlPath (o driver proxy já remove o prefixo).
LOG_ST = "/tmp/minibi_streamlit.log"
env = {**os.environ,
       "MINIBI_BRIDGE_PORT": str(PORTA_BRIDGE), "MINIBI_BRIDGE_TOKEN": TOKEN,
       "MINIBI_CONFIG": os.path.join(APP_DIR, "dashboards.yaml"),
       "STREAMLIT_BROWSER_GATHER_USAGE_STATS": "false"}
cmd = [sys.executable, "-m", "streamlit", "run", os.path.join(APP_DIR, "app.py"),
       "--server.port", str(PORTA), "--server.headless", "true",
       "--server.enableCORS", "false", "--server.enableXsrfProtection", "false",
       "--server.fileWatcherType", "none", "--theme.base", "light"]
_MINIBI_ST = subprocess.Popen(cmd, env=env, cwd="/tmp", stdout=open(LOG_ST, "w"), stderr=subprocess.STDOUT,
                              start_new_session=True)

for _ in range(60):
    try:
        if requests.get(f"http://127.0.0.1:{PORTA}/_stcore/health", timeout=2).ok:
            break
    except Exception:
        pass
    if _MINIBI_ST.poll() is not None:
        raise RuntimeError("Streamlit encerrou:\n" + open(LOG_ST).read()[-3000:])
    time.sleep(1)
else:
    raise RuntimeError("Streamlit não ficou saudável em 60 s:\n" + open(LOG_ST).read()[-3000:])

# --- 4) link -----------------------------------------------------------------------------
url = f"{host}/driver-proxy/o/{org_id}/{cluster_id}/{PORTA}/"
displayHTML(f"""
  <div style="font-family:system-ui;padding:16px;border:1px solid #ddd;border-radius:12px">
    <div style="font-size:18px;font-weight:600">📊 Mini BI no ar</div>
    <p><a href="{url}" target="_blank" style="font-size:16px">{url}</a></p>
    <p style="color:#777">Mantenha a célula de keep-alive rodando enquanto usa o app.</p>
  </div>""")

# COMMAND ----------

# DBTITLE 1,Keep-alive (deixe rodando enquanto usa o app)
# Mantém o notebook ativo (evita auto-termination por ociosidade) e avisa se o Streamlit cair.
import time
try:
    while True:
        if _MINIBI_ST.poll() is not None:
            print("Streamlit caiu — veja a célula Diagnóstico e rode a célula de subida de novo.")
            break
        time.sleep(30)
except KeyboardInterrupt:
    print("Keep-alive interrompido (o app continua enquanto o cluster estiver ligado).")

# COMMAND ----------

# DBTITLE 1,Parar tudo
if _MINIBI_ST.poll() is None:
    _MINIBI_ST.terminate()
bridge.parar_bridge()
print("🛑 Mini BI encerrado.")

# COMMAND ----------

# DBTITLE 1,Diagnóstico
print(open("/tmp/minibi_streamlit.log").read()[-4000:])
